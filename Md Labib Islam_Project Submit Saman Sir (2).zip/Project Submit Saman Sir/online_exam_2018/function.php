<?php
// Email validation
function email_validation($email){
  $regex = '/([a-z0-9])+\@+(a-z)+(\.)+([a-z]{2,6})/';
  if (preg_match($regex,$email)) {
    return 1;
  }else {
    return 0;
  }
}

?>
