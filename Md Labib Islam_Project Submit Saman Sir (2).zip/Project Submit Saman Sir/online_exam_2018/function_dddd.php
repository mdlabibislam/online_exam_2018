<?php
// Email validation
function email_validation($email){
  $regex = '/([a-z0-9])+\@+(a-z)+(\.)+([a-z]{2,6})/';
  if (preg_match($regex,$email)) {
    return 1;
  }else {
    return 0;
  }
}
// Bangladesh mobile numbser validation
// function mobile_validation($mobile){
//   $regex = '/01[^1-4]\d{8}/';
//   if (preg_match(regex,$mobile)) {
//     return 1;
//   }else {
//     return 0;
//   }
// }
?>
