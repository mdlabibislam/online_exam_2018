 </section>
<section class="footeroption">
		<h2><?php echo "LICT Online Exam System 2018"; ?></h2>
	</section>
</div>
</body>
</html>
