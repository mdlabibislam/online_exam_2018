<?php
    $filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/inc/header.php');
?>
<style>
	.main{


	}
	.main h1{
		font-family: "Times New Roman", Georgia, Serif;
		font-size: 40px;
		color:black;
	}
	.adminpanel{
		width:590px;
		color:red;
		margin:30px auto 0;
		padding:50px;
		border:2px solid #ddd;
		font-family: "Times New Roman", Georgia, Serif;
		font-size: 28px;
		}
</style>
<div class="main">
<h1>Admin Panel</h1>
	<div class = "adminpanel">
		<marquee><h2>Welcome to Control Admin Panel for LICT Online Exam System 2018</h2></marquee>
		<p>You can manage User and Online Exam from here</p>
	</div>
</div>
<?php include 'inc/footer.php'; ?>
