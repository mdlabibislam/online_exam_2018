 <style>
 .footeroption{background:#202633;color:#fff;text-align:center;padding:20px;font-family: "Times New Roman", Times, serif;}
 </style>

</section>
<section class="footeroption">
		<pre><h2><?php echo "LICT Online Exam System"; ?></h2></pre>
	</section>
</div>
</body>
</html>
