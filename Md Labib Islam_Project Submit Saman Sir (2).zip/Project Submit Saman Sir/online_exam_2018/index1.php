<?php
require ('function.php');
$ip='localhost';
$username='root';
$password='';
$dbname='online_exam_2018';
$conn=mysqli_connect($ip,$username,$password,$dbname);
if (isset($_POST['submit'])) {
  $email=$_POST['email'];
  if (email_validation($email)==1) {
    $sql="INSERT INTO regex(`email_id`) VALUES('{$email}')";
    $result = mysqli_query($conn,$sql);
    if ($result) {
      echo "Data inserted successfully";
    }else {
      echo "ERROR : Data not inserted into database";
    }
  }else{
      echo "<scrip>alert('Incorrect Email ID')<script>";
    }
  }
  require("index.html1");

?>
