-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2018 at 08:56 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_exam_2018`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminUser` varchar(50) NOT NULL,
  `adminPass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminUser`, `adminPass`) VALUES
(1, 'mdlabibislam', '@#labib@#'),
(5, 'lict_saman', 'lict_28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ans`
--

CREATE TABLE `tbl_ans` (
  `id` int(11) NOT NULL,
  `quesNo` int(11) NOT NULL,
  `rightAns` int(11) NOT NULL DEFAULT '0',
  `ans` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ans`
--

INSERT INTO `tbl_ans` (`id`, `quesNo`, `rightAns`, `ans`) VALUES
(168, 1, 0, 'P'),
(169, 1, 1, 'Hr'),
(170, 1, 0, 'Ol'),
(171, 1, 0, 'Ul'),
(172, 2, 0, 'Ol'),
(173, 2, 1, 'Ul'),
(174, 2, 0, 'Pl'),
(175, 2, 0, 'Tl'),
(176, 3, 0, 'Border-color'),
(177, 3, 0, 'Border color'),
(178, 3, 1, 'Bordercolor'),
(179, 3, 0, 'Border:color'),
(180, 4, 0, 'Netscape'),
(181, 4, 0, 'Firefox'),
(182, 4, 0, 'Chrome'),
(183, 4, 1, 'Internet Explorer'),
(184, 5, 0, 'Cell spacing'),
(185, 5, 1, 'Cell padding'),
(186, 5, 0, 'Cell shaping'),
(187, 5, 0, 'Cell framing'),
(188, 6, 0, 'Work station'),
(189, 6, 0, 'Core i 5 CPU'),
(190, 6, 1, 'Web Server'),
(191, 6, 0, 'LAN'),
(212, 7, 0, 'Background color'),
(213, 7, 1, 'Background image'),
(214, 7, 0, 'Watercolor'),
(215, 7, 0, 'Watermark');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ques`
--

CREATE TABLE `tbl_ques` (
  `id` int(11) NOT NULL,
  `quesNo` int(11) NOT NULL,
  `ques` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ques`
--

INSERT INTO `tbl_ques` (`id`, `quesNo`, `ques`) VALUES
(50, 1, 'Which option is used to create a horizontal ruler in a web page?'),
(51, 2, 'Which of the following is a bulleted list?'),
(52, 3, 'What attribute is used to give border color to a table in HTML?'),
(53, 4, 'Basefont tag works only in the following browser.'),
(54, 5, 'The space between the table data value and its border is called?'),
(55, 6, 'A web site is stored on a ?'),
(61, 7, 'The background attribute of body tag is used for? ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`userid`, `name`, `username`, `password`, `email`, `status`) VALUES
(10, 'md labib islam', 'mdlabibislam', '258c423f693ddc6d39b18eb08153d3f2', 'mdlabibislam@gmail.com', 0),
(11, 'afsana farhim jemi', 'farhim', '258c423f693ddc6d39b18eb08153d3f2', 'afsanafarhimjemi@gmail.com', 0),
(13, 'sabuj', 'sabuj', '258c423f693ddc6d39b18eb08153d3f2', 'ledp.sabuj@gmail.com', 0),
(23, 'md labib islam', 'mdlabibislam2018', '81dc9bdb52d04dc20036dbd8313ed055', 'suman11@iit.ernet.in', 0),
(24, 'alamin', 'alamin', 'd061f4891bd39deb65390f62677c38d1', 'alamin@hotmail.com', 0),
(25, '.md. asld @ lsadk#kdasdf', '.md. asld @ lsadk#kdasdf', 'fba181b041d157e75b0712e721bdd700', 'md.asldlsadk#kdasdf@gmail.com', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_ans`
--
ALTER TABLE `tbl_ans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ques`
--
ALTER TABLE `tbl_ques`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_ans`
--
ALTER TABLE `tbl_ans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;

--
-- AUTO_INCREMENT for table `tbl_ques`
--
ALTER TABLE `tbl_ques`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
